#!/usr/bin/env python3
"""
將一張貼圖圖片去除背景為透明，切割為12張小圖。
每張小圖約 370 x 320 px（自動等比例縮放填滿排列）。
每張貼圖四周預留 0.2cm。
"""

from PIL import Image
import os
from pathlib import Path
import numpy as np

def remove_background(image, threshold=30):
    """
    移除圖片背景（假設背景是綠色或均勻顏色）。
    
    Args:
        image: PIL Image 物件
        threshold: 顏色閾值
    
    Returns:
        去除背景後的 RGBA 圖片
    """
    # 轉換為 RGBA
    if image.mode != 'RGBA':
        image = image.convert('RGBA')
    
    # 轉換為 numpy 陣列
    data = np.array(image)
    
    # 獲取四個角的像素來偵測背景顏色
    corners = [
        data[0, 0],  # 左上角
        data[0, -1],  # 右上角
        data[-1, 0],  # 左下角
        data[-1, -1],  # 右下角
    ]
    
    # 取平均背景顏色（假設大部分角是背景）
    bg_color = np.mean(corners, axis=0)[:3]  # 只取 RGB
    
    print(f"偵測到背景顏色 (RGB): {bg_color}")
    
    # 計算每個像素與背景顏色的差異
    r, g, b = data[:, :, 0], data[:, :, 1], data[:, :, 2]
    bg_r, bg_g, bg_b = bg_color
    
    # 如果像素接近背景顏色，設定透明度為 0
    color_diff = np.sqrt((r.astype(float) - bg_r) ** 2 + 
                         (g.astype(float) - bg_g) ** 2 + 
                         (b.astype(float) - bg_b) ** 2)
    
    # 使用閾值判斷
    alpha = np.where(color_diff < threshold, 0, 255).astype(np.uint8)
    
    # 更新 alpha 通道
    data[:, :, 3] = alpha
    
    return Image.fromarray(data, 'RGBA')

def crop_stickers(input_image_path, output_dir="output_stickers", remove_bg=True):
    """
    將貼圖圖片去除背景並切割為12張小圖。
    
    Args:
        input_image_path: 輸入圖片的路徑
        output_dir: 輸出目錄
        remove_bg: 是否移除背景
    """
    # 創建輸出目錄
    Path(output_dir).mkdir(exist_ok=True)
    
    # 打開原始圖片
    img = Image.open(input_image_path)
    width, height = img.size
    print(f"原始圖片尺寸: {width} x {height} px")
    
    # 移除背景（如果需要）
    if remove_bg:
        print("開始移除背景...")
        img = remove_background(img, threshold=30)
        print("✓ 背景移除完成")
    
    # 目標尺寸（以像素為單位）
    target_width = 370
    target_height = 320
    
    # 0.2cm 對應的像素數（假設 DPI 為 96）
    # 0.2cm = 0.2/2.54 inches ≈ 0.0787 inches
    # 0.0787 inches * 96 DPI ≈ 7.56 pixels，約 8 pixels
    margin_pixels = 8
    
    # 計算內容區域尺寸（考慮邊距）
    content_width = target_width - 2 * margin_pixels
    content_height = target_height - 2 * margin_pixels
    
    print(f"目標尺寸: {target_width} x {target_height} px")
    print(f"邊距: {margin_pixels} px (≈ 0.2cm)")
    print(f"內容區域: {content_width} x {content_height} px")
    
    # 假設圖片排列為 4 列 3 行（4x3 = 12張）
    rows = 3
    cols = 4
    
    # 計算每個網格的寬度和高度（不包括邊距）
    grid_width = width // cols
    grid_height = height // rows
    
    print(f"計算出的網格尺寸: {grid_width} x {grid_height} px")
    print(f"開始切割圖片...")
    
    counter = 1
    
    # 遍歷每一行每一列
    for row in range(rows):
        for col in range(cols):
            # 計算裁切區域
            left = col * grid_width
            top = row * grid_height
            right = left + grid_width
            bottom = top + grid_height
            
            # 裁切原始圖片
            cropped = img.crop((left, top, right, bottom))
            
            # 等比例縮放至內容區域大小
            cropped.thumbnail((content_width, content_height), Image.Resampling.LANCZOS)
            
            # 創建最終輸出圖片（包含邊距）
            final_img = Image.new('RGBA', (target_width, target_height), (0, 0, 0, 0))
            
            # 計算貼上位置（居中）
            paste_x = (target_width - cropped.width) // 2
            paste_y = (target_height - cropped.height) // 2
            
            # 將縮放後的圖片貼到最終圖片的中央
            final_img.paste(cropped, (paste_x, paste_y), cropped if cropped.mode == 'RGBA' else None)
            
            # 保存圖片
            output_path = os.path.join(output_dir, f"sticker_{counter:02d}.png")
            final_img.save(output_path, 'PNG')
            print(f"✓ 已保存: {output_path}")
            
            counter += 1
    
    print(f"\n✅ 完成！共產生 {counter - 1} 張貼圖")
    print(f"輸出目錄: {os.path.abspath(output_dir)}")


if __name__ == "__main__":
    # 取得當前目錄下的 PNG 檔案
    current_dir = os.path.dirname(os.path.abspath(__file__))
    png_files = list(Path(current_dir).glob("*.png"))
    
    if png_files:
        input_file = str(png_files[0])
        print(f"找到圖片: {input_file}\n")
        crop_stickers(input_file)
    else:
        print("❌ 錯誤: 未找到 PNG 圖片檔案")
        print("請確保圖片檔案與此指令碼在同一目錄中")

#!/usr/bin/env python3
"""
將一張貼圖圖片去除背景為透明，切割為12張小圖。
每張小圖約 370 x 320 px（自動等比例縮放填滿排列）。
每張貼圖四周預留 0.2cm。
改進版本：更好的邊緣清潔和溢色去除。
"""

from PIL import Image, ImageFilter
import os
from pathlib import Path

def remove_background_color(image, bg_color_hex_list=["#00ff00", "#00ff00"], threshold=30, feather=2, remove_fringe=True):
    """
    移除圖片背景（基於指定的顏色列表）。
    三階段處理：預清潔 -> Alpha 生成 -> 後期清潔
    
    Args:
        image: PIL Image 物件
        bg_color_hex_list: 背景顏色列表（16進制色號）
        threshold: 顏色距離閾值
        feather: 邊緣柔化程度
        remove_fringe: 是否去除溢色
    
    Returns:
        去除背景後的 RGBA 圖片
    """
    # 轉換為 RGBA
    if image.mode != 'RGBA':
        image = image.convert('RGBA')
    
    # 解析所有背景顏色
    bg_colors = []
    for bg_color_hex in bg_color_hex_list:
        bg_hex = bg_color_hex.lstrip('#')
        bg_r = int(bg_hex[0:2], 16)
        bg_g = int(bg_hex[2:4], 16)
        bg_b = int(bg_hex[4:6], 16)
        bg_colors.append((bg_r, bg_g, bg_b))
        print(f"移除背景顏色: #{bg_hex.upper()} RGB({bg_r}, {bg_g}, {bg_b})")
    
    # 【第一階段】預清潔：減少背景色污染
    print("進行中... 第一階段：預清潔邊緣")
    image = remove_fringe_pre_process(image, bg_colors)
    
    # 【第二階段】生成 Alpha 通道
    print("進行中... 第二階段：生成 Alpha 通道")
    data = list(image.getdata())
    new_data = []
    
    for item in data:
        if len(item) == 4:
            r, g, b, a = item
        else:
            r, g, b = item
            a = 255
        
        # 計算與每個背景顏色的距離，取最小值
        min_dist = float('inf')
        for bg_r, bg_g, bg_b in bg_colors:
            dist = ((r - bg_r) ** 2 + (g - bg_g) ** 2 + (b - bg_b) ** 2) ** 0.5
            min_dist = min(min_dist, dist)
        
        # 根據距離生成 alpha
        if min_dist < threshold:
            new_data.append((r, g, b, 0))
        else:
            # 漸進式透明度
            alpha = min(255, int((min_dist / threshold) * 255))
            new_data.append((r, g, b, alpha))
    
    result = Image.new('RGBA', image.size)
    result.putdata(new_data)
    
    # 邊緣柔化
    if feather > 0:
        print(f"進行中... 邊緣柔化（半徑: {feather}px）")
        result = result.filter(ImageFilter.GaussianBlur(radius=feather))
    
    # 【第三階段】後期清潔：強力去除半透明邊緣的溢色
    if remove_fringe:
        print("進行中... 第三階段：後期清潔溢色")
        result = remove_fringe_post_process(result, bg_colors)
    
    return result

def remove_fringe_pre_process(image, bg_colors):
    """
    預處理階段：減少背景色對邊緣的污染。
    """
    data = list(image.getdata())
    new_data = []
    
    for item in data:
        if len(item) == 4:
            r, g, b, a = item
        else:
            r, g, b = item
            a = 255
        
        # 找到最接近的背景顏色
        min_dist = float('inf')
        closest_bg = bg_colors[0]
        for bg_r, bg_g, bg_b in bg_colors:
            dist = ((r - bg_r) ** 2 + (g - bg_g) ** 2 + (b - bg_b) ** 2) ** 0.5
            if dist < min_dist:
                min_dist = dist
                closest_bg = (bg_r, bg_g, bg_b)
        
        # 如果像素接近背景色，進行預清潔
        # 使用更寬鬆的閾值來檢測可能受污染的像素
        if min_dist < 80:
            # 計算污染程度（0 到 1）
            contamination = max(0, 1 - (min_dist / 80))
            
            # 激進地減少背景色影響（係數 0.7 表示保留 70% 的原色，去除 30% 的背景色）
            r = max(0, min(255, int(r - closest_bg[0] * contamination * 0.7)))
            g = max(0, min(255, int(g - closest_bg[1] * contamination * 0.7)))
            b = max(0, min(255, int(b - closest_bg[2] * contamination * 0.7)))
        
        new_data.append((r, g, b, a))
    
    result = Image.new('RGBA', image.size)
    result.putdata(new_data)
    return result

def remove_fringe_post_process(image, bg_colors):
    """
    後處理階段：使用反卷積去除半透明邊緣的溢色。
    """
    data = list(image.getdata())
    width, height = image.size
    
    new_data = []
    for item in data:
        if len(item) == 4:
            r, g, b, a = item
            
            # 只處理半透明像素（0 < alpha < 255）
            if 0 < a < 240:
                # 找到最接近的背景顏色
                min_dist = float('inf')
                closest_bg = bg_colors[0]
                for bg_r, bg_g, bg_b in bg_colors:
                    dist = ((r - bg_r) ** 2 + (g - bg_g) ** 2 + (b - bg_b) ** 2) ** 0.5
                    if dist < min_dist:
                        min_dist = dist
                        closest_bg = (bg_r, bg_g, bg_b)
                
                # 反卷積公式去除背景色
                # 像素 = 前景色 * alpha + 背景色 * (1 - alpha)
                # 前景色 = (像素 - 背景色 * (1 - alpha)) / alpha
                alpha_norm = a / 255.0
                
                # 使用更激進的系數來強力去除背景色
                if alpha_norm > 0.05:
                    decontamination = 1.2  # > 1.0 會更激進地去除背景色
                    
                    r = max(0, min(255, int((r - closest_bg[0] * (1 - alpha_norm) * decontamination))))
                    g = max(0, min(255, int((g - closest_bg[1] * (1 - alpha_norm) * decontamination))))
                    b = max(0, min(255, int((b - closest_bg[2] * (1 - alpha_norm) * decontamination))))
                
                new_data.append((r, g, b, a))
            else:
                new_data.append(item)
        else:
            new_data.append(item)
    
    result = Image.new('RGBA', image.size)
    result.putdata(new_data)
    return result

def crop_stickers(input_image_path, output_dir="output_stickers", remove_bg=True, bg_colors=["#00ff00", "#ffffff"]):
    """
    將貼圖圖片去除背景並切割為12張小圖。
    
    Args:
        input_image_path: 輸入圖片的路徑
        output_dir: 輸出目錄
        remove_bg: 是否移除背景
        bg_colors: 背景顏色列表（16進制色號）
    """
    # 創建輸出目錄
    Path(output_dir).mkdir(exist_ok=True)
    
    # 打開原始圖片
    img = Image.open(input_image_path)
    width, height = img.size
    print(f"原始圖片尺寸: {width} x {height} px\n")
    
    # 移除背景（如果需要）
    if remove_bg:
        print("=== 開始移除背景 ===")
        img = remove_background_color(img, bg_color_hex_list=bg_colors, threshold=100, feather=0, remove_fringe=True)
        print("✓ 背景移除完成\n")
    
    # 確保是 RGBA 模式
    if img.mode != 'RGBA':
        img = img.convert('RGBA')
    
    # 目標尺寸（以像素為單位）
    target_width = 370
    target_height = 320
    
    # 0.2cm 對應的像素數（假設 DPI 為 96）
    margin_pixels = 8
    
    # 計算內容區域尺寸（考慮邊距）
    content_width = target_width - 2 * margin_pixels
    content_height = target_height - 2 * margin_pixels
    
    print(f"=== 開始切割圖片 ===")
    print(f"目標尺寸: {target_width} x {target_height} px")
    print(f"邊距: {margin_pixels} px (≈ 0.2cm)")
    print(f"內容區域: {content_width} x {content_height} px\n")
    
    # 假設圖片排列為 4 列 3 行（4x3 = 12張）
    rows = 3
    cols = 4
    
    # 計算每個網格的寬度和高度
    grid_width = width // cols
    grid_height = height // rows
    
    print(f"計算出的網格尺寸: {grid_width} x {grid_height} px")
    print(f"開始切割...\n")
    
    counter = 1
    
    # 遍歷每一行每一列
    for row in range(rows):
        for col in range(cols):
            # 計算裁切區域
            left = col * grid_width
            top = row * grid_height
            right = left + grid_width
            bottom = top + grid_height
            
            # 裁切原始圖片
            cropped = img.crop((left, top, right, bottom))
            
            # 等比例縮放至內容區域大小
            cropped.thumbnail((content_width, content_height), Image.Resampling.LANCZOS)
            
            # 創建最終輸出圖片（包含邊距）
            final_img = Image.new('RGBA', (target_width, target_height), (0, 0, 0, 0))
            
            # 計算貼上位置（居中）
            paste_x = (target_width - cropped.width) // 2
            paste_y = (target_height - cropped.height) // 2
            
            # 將縮放後的圖片貼到最終圖片的中央
            final_img.paste(cropped, (paste_x, paste_y), cropped)
            
            # 保存圖片
            output_path = os.path.join(output_dir, f"sticker_{counter:02d}.png")
            final_img.save(output_path, 'PNG')
            print(f"✓ 已保存: sticker_{counter:02d}.png")
            
            counter += 1
    
    print(f"\n✅ 完成！共產生 {counter - 1} 張貼圖")
    print(f"輸出目錄: {os.path.abspath(output_dir)}")


if __name__ == "__main__":
    # 取得當前目錄下的圖片檔案
    current_dir = os.path.dirname(os.path.abspath(__file__))
    image_files = list(Path(current_dir).glob("*.png")) + list(Path(current_dir).glob("*.jpg")) + list(Path(current_dir).glob("*.jpeg"))
    
    # 排除已處理的檔案
    input_files = [f for f in image_files if "sticker_" not in f.name]
    
    if input_files:
        input_file = str(input_files[0])
        print(f"找到圖片: {input_file}\n")
        crop_stickers(input_file)
    else:
        print("❌ 錯誤: 未找到圖片檔案")
        print("請確保圖片檔案與此指令碼在同一目錄中")

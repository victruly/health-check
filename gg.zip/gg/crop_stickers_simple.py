#!/usr/bin/env python3
"""
將一張貼圖圖片去除背景為透明，切割為12張小圖。
每張小圖約 370 x 320 px（自動等比例縮放填滿排列）。
每張貼圖四周預留 0.2cm。
"""

from PIL import Image, ImageChops, ImageFilter
import os
from pathlib import Path

def remove_background_color(image, bg_color_hex="#00ff00", threshold=30, feather=0, remove_fringe=True):
    """
    移除圖片背景（基於指定的顏色）。
    
    Args:
        image: PIL Image 物件
        bg_color_hex: 背景顏色（16進制色號，如 "#00ff00"）
        threshold: 顏色距離閾值
        feather: 邊緣柔化程度
        remove_fringe: 是否去除溢色
    
    Returns:
        去除背景後的 RGBA 圖片
    """
    # 轉換為 RGBA
    if image.mode != 'RGBA':
        image = image.convert('RGBA')
    
    # 解析 hex 色號為 RGB
    bg_hex = bg_color_hex.lstrip('#')
    bg_r = int(bg_hex[0:2], 16)
    bg_g = int(bg_hex[2:4], 16)
    bg_b = int(bg_hex[4:6], 16)
    bg_color = (bg_r, bg_g, bg_b)
    
    print(f"移除背景顏色: #{bg_hex.upper()} RGB({bg_r}, {bg_g}, {bg_b})")
    
    # 創建新的 RGBA 圖片
    data = image.getdata()
    new_data = []
    
    # 遍歷每個像素
    for item in data:
        # 獲取 RGB 值
        if len(item) == 4:  # RGBA
            r, g, b, a = item
        else:  # RGB
            r, g, b = item
            a = 255
        
        # 計算與背景顏色的距離
        dist = ((r - bg_r) ** 2 + (g - bg_g) ** 2 + (b - bg_b) ** 2) ** 0.5
        
        # 如果接近背景顏色，設定為透明；否則根據距離計算 alpha（實現邊緣柔化）
        if dist < threshold:
            new_data.append((r, g, b, 0))
        else:
            # 邊緣柔化：根據距離漸進式改變透明度
            alpha = min(255, int((dist / threshold) * 255))
            new_data.append((r, g, b, alpha))
    
    result = Image.new('RGBA', image.size)
    result.putdata(new_data)
    
    # 邊緣柔化處理
    if feather > 0:
        result = result.filter(ImageFilter.GaussianBlur(radius=feather))
    
    # 溢色去除：對邊緣進行色彩調整以去除背景色溢色
    if remove_fringe:
        result = remove_color_fringe(result, (bg_r, bg_g, bg_b))
    
    return result

def remove_color_fringe(image, bg_color):
    """
    移除邊緣溢色（背景顏色污染）。
    
    Args:
        image: RGBA 圖片
        bg_color: 背景顏色 (R, G, B)
    
    Returns:
        去除溢色後的圖片
    """
    data = list(image.getdata())
    width, height = image.size
    
    for i, item in enumerate(data):
        if len(item) == 4:
            r, g, b, a = item
            
            # 只處理半透明像素（邊緣）
            if 0 < a < 255:
                # 反卷積去除背景色污染
                # 公式: cleaned_color = (pixel_color - bg_color * (1 - alpha)) / alpha
                alpha_norm = a / 255.0
                
                if alpha_norm > 0:
                    r = max(0, min(255, int((r - bg_color[0] * (1 - alpha_norm)) / alpha_norm)))
                    g = max(0, min(255, int((g - bg_color[1] * (1 - alpha_norm)) / alpha_norm)))
                    b = max(0, min(255, int((b - bg_color[2] * (1 - alpha_norm)) / alpha_norm)))
                
                data[i] = (r, g, b, a)
    
    result = Image.new('RGBA', image.size)
    result.putdata(data)
    return result

def crop_stickers(input_image_path, output_dir="output_stickers", remove_bg=True, bg_color="#00ff00"):
    """
    將貼圖圖片去除背景並切割為12張小圖。
    
    Args:
        input_image_path: 輸入圖片的路徑
        output_dir: 輸出目錄
        remove_bg: 是否移除背景
        bg_color: 背景顏色（16進制色號，如 "#00ff00"）
    """
    # 創建輸出目錄
    Path(output_dir).mkdir(exist_ok=True)
    
    # 打開原始圖片
    img = Image.open(input_image_path)
    width, height = img.size
    print(f"原始圖片尺寸: {width} x {height} px")
    
    # 移除背景（如果需要）
    if remove_bg:
        print("開始移除背景...")
        img = remove_background_color(img, bg_color_hex=bg_color, threshold=120, feather=0, remove_fringe=True)
        print("✓ 背景移除完成（已套用邊緣柔化和溢色去除）")
    
    # 確保是 RGBA 模式
    if img.mode != 'RGBA':
        img = img.convert('RGBA')
    
    # 目標尺寸（以像素為單位）
    target_width = 370
    target_height = 320
    
    # 0.2cm 對應的像素數（假設 DPI 為 96）
    # 0.2cm = 0.2/2.54 inches ≈ 0.0787 inches
    # 0.0787 inches * 96 DPI ≈ 7.56 pixels，約 8 pixels
    margin_pixels = 8
    
    # 計算內容區域尺寸（考慮邊距）
    content_width = target_width - 2 * margin_pixels
    content_height = target_height - 2 * margin_pixels
    
    print(f"目標尺寸: {target_width} x {target_height} px")
    print(f"邊距: {margin_pixels} px (≈ 0.2cm)")
    print(f"內容區域: {content_width} x {content_height} px")
    
    # 假設圖片排列為 4 列 3 行（4x3 = 12張）
    rows = 3
    cols = 4
    
    # 計算每個網格的寬度和高度
    grid_width = width // cols
    grid_height = height // rows
    
    print(f"計算出的網格尺寸: {grid_width} x {grid_height} px")
    print(f"開始切割圖片...\n")
    
    counter = 1
    
    # 遍歷每一行每一列
    for row in range(rows):
        for col in range(cols):
            # 計算裁切區域
            left = col * grid_width
            top = row * grid_height
            right = left + grid_width
            bottom = top + grid_height
            
            # 裁切原始圖片
            cropped = img.crop((left, top, right, bottom))
            
            # 等比例縮放至內容區域大小
            cropped.thumbnail((content_width, content_height), Image.Resampling.LANCZOS)
            
            # 創建最終輸出圖片（包含邊距）
            final_img = Image.new('RGBA', (target_width, target_height), (0, 0, 0, 0))
            
            # 計算貼上位置（居中）
            paste_x = (target_width - cropped.width) // 2
            paste_y = (target_height - cropped.height) // 2
            
            # 將縮放後的圖片貼到最終圖片的中央
            final_img.paste(cropped, (paste_x, paste_y), cropped)
            
            # 保存圖片
            output_path = os.path.join(output_dir, f"sticker_{counter:02d}.png")
            final_img.save(output_path, 'PNG')
            print(f"✓ 已保存: sticker_{counter:02d}.png ({target_width}x{target_height}px)")
            
            counter += 1
    
    print(f"\n✅ 完成！共產生 {counter - 1} 張貼圖")
    print(f"輸出目錄: {os.path.abspath(output_dir)}")


if __name__ == "__main__":
    # 取得當前目錄下的 PNG 或 JPG 檔案
    current_dir = os.path.dirname(os.path.abspath(__file__))
    image_files = list(Path(current_dir).glob("*.png")) + list(Path(current_dir).glob("*.jpg")) + list(Path(current_dir).glob("*.jpeg"))
    
    # 排除已處理的檔案
    input_files = [f for f in image_files if "sticker_" not in f.name]
    
    if input_files:
        input_file = str(input_files[0])
        print(f"找到圖片: {input_file}\n")
        crop_stickers(input_file)
    else:
        print("❌ 錯誤: 未找到圖片檔案")
        print("請確保圖片檔案與此指令碼在同一目錄中")
